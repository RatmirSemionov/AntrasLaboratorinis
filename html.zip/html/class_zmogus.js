var class_zmogus =
[
    [ "Zmogus", "class_zmogus.html#ac7034e8672e7feda0e3e1303a5336f2b", null ],
    [ "~Zmogus", "class_zmogus.html#ac5615bf607a8f2f1b303ffa04328d24d", null ],
    [ "informacija", "class_zmogus.html#a5526e6fefc56ccc370a9766e62e0232d", null ],
    [ "pavarde", "class_zmogus.html#aba9f5c58201207c9ada551baceb1eea0", null ],
    [ "setpavarde", "class_zmogus.html#ac8090aa4ac44502984aa4ebf566461b1", null ],
    [ "setvardas", "class_zmogus.html#ad2567661dcd94125af0fe99bba975b54", null ],
    [ "vardas", "class_zmogus.html#a27a248ac6c61fa29d8f98383892f6ab8", null ],
    [ "Pavarde", "class_zmogus.html#a2300d6db4227967c96dd83a555fa7b86", null ],
    [ "Vardas", "class_zmogus.html#ad752feab373733e70e2101724e8d1d9d", null ]
];