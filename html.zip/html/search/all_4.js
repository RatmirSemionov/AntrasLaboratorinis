var searchData=
[
  ['getpazymiai_0',['getPazymiai',['../class_studentas.html#a02b6569858027e17ef02ebb0ce886b86',1,'Studentas']]]
];
