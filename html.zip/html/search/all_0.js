var searchData=
[
  ['addpazymys_0',['addPazymys',['../class_studentas.html#ac64090134601173b29cf0bc7df6c4cc6',1,'Studentas']]]
];
