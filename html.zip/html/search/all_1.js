var searchData=
[
  ['comparebygrade_0',['comparebygrade',['../mylib_8cpp.html#a1171e182c2ad4a627e6170591f1ff420',1,'compareByGrade(const Studentas &amp;a, const Studentas &amp;b):&#160;mylib.cpp'],['../mylib_8h.html#a1171e182c2ad4a627e6170591f1ff420',1,'compareByGrade(const Studentas &amp;a, const Studentas &amp;b):&#160;mylib.cpp']]],
  ['comparebyname_1',['comparebyname',['../mylib_8cpp.html#ac3a31b2310d65b42b64a422eb9469e94',1,'compareByName(const Studentas &amp;a, const Studentas &amp;b):&#160;mylib.cpp'],['../mylib_8h.html#ac3a31b2310d65b42b64a422eb9469e94',1,'compareByName(const Studentas &amp;a, const Studentas &amp;b):&#160;mylib.cpp']]],
  ['comparebysurname_2',['comparebysurname',['../mylib_8cpp.html#ac9f79a59b71048ff03515ccec1d0ec96',1,'compareBySurname(const Studentas &amp;a, const Studentas &amp;b):&#160;mylib.cpp'],['../mylib_8h.html#ac9f79a59b71048ff03515ccec1d0ec96',1,'compareBySurname(const Studentas &amp;a, const Studentas &amp;b):&#160;mylib.cpp']]]
];
