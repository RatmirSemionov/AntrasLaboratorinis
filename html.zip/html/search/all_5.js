var searchData=
[
  ['informacija_0',['informacija',['../class_zmogus.html#a5526e6fefc56ccc370a9766e62e0232d',1,'Zmogus::informacija()'],['../class_studentas.html#ad2e8a624618a6d49415f348bf0052a98',1,'Studentas::informacija()']]]
];
