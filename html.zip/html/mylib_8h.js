var mylib_8h =
[
    [ "Zmogus", "class_zmogus.html", "class_zmogus" ],
    [ "Studentas", "class_studentas.html", "class_studentas" ],
    [ "compareByGrade", "mylib_8h.html#a1171e182c2ad4a627e6170591f1ff420", null ],
    [ "compareByName", "mylib_8h.html#ac3a31b2310d65b42b64a422eb9469e94", null ],
    [ "compareBySurname", "mylib_8h.html#ac9f79a59b71048ff03515ccec1d0ec96", null ],
    [ "EgzaminoPazymis", "mylib_8h.html#a398ee27bb33717f0a246b5f60d14eac8", null ],
    [ "FailoSkaitymas", "mylib_8h.html#a7b75b5c624d562968b55c4b9ecb58c8a", null ],
    [ "KategorijuFailai", "mylib_8h.html#a786b0f4992c9386d005bea1bce4b961d", null ],
    [ "KategorizuotiStudentus", "mylib_8h.html#aad7d4900a005aabd0e5e112c67f40552", null ],
    [ "Mediana", "mylib_8h.html#a091b831c3ba4a107e4efceb31e80e71e", null ],
    [ "PazymiuGeneravimas", "mylib_8h.html#a93d280ca8f86a9ceac8ca2f1d300f625", null ],
    [ "PazymiuIvedimas", "mylib_8h.html#a170b76decc3438e9f70651c596d0e194", null ],
    [ "RezultatoFailas", "mylib_8h.html#a62f4f74fdb5adb22fc995d7db78b341b", null ],
    [ "Rusiavimas", "mylib_8h.html#a7d17fe71d05863193778b3c8fb5e6cc4", null ],
    [ "StudentuInfo", "mylib_8h.html#a36c1e829a73e6fd25e94b282c56c36bf", null ],
    [ "SukurtiStudentoFaila", "mylib_8h.html#a7dfab294b85c1670df0c4ee6cdec75a6", null ],
    [ "Vidurkis", "mylib_8h.html#ad836afab61420c9b772a5f75eccb8915", null ]
];