var files_dup =
[
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "mylib.cpp", "mylib_8cpp.html", "mylib_8cpp" ],
    [ "mylib.h", "mylib_8h.html", "mylib_8h" ]
];